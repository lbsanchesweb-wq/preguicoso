import React, { useEffect, useRef, useState } from 'react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [text, setText] = useState('');
  const [progressText, setProgressText] = useState('');
  const [showImage, setShowImage] = useState(false);
  const [isFadingOut, setIsFadingOut] = useState(false);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  const FULL_TEXT = "Sabe como tornar uma tarefa complicada em algo fácil?\nDelegue a um preguiçoso. 🦥";

  // --- CANVAS ANIMATION ---
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    const pixels = Array.from({ length: 80 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      size: Math.random() * 3 + 2,
      color: Math.random() < 0.5 ? "#00baff" : "#ff4ff0",
      speed: Math.random() * 1 + 0.5
    }));

    let animationId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      pixels.forEach(p => {
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, p.size, p.size);
        p.y -= p.speed;
        if (p.y < 0) p.y = canvas.height;
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();
    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  // --- BOOT SEQUENCE LOGIC ---
  useEffect(() => {
    // 1. Play Sound & Show Image
    const playAudio = async () => {
      if (audioRef.current) {
        audioRef.current.volume = 0.3;
        try {
          await audioRef.current.play();
        } catch (e) {
          console.log("Autoplay blocked by browser, continuing silently.");
        }
      }
    };

    playAudio();
    setTimeout(() => setShowImage(true), 500);

    // 2. Typing Effect
    let charIndex = 0;
    const typeTimer = setTimeout(() => {
        const typeInterval = setInterval(() => {
            if (charIndex < FULL_TEXT.length) {
                setText(FULL_TEXT.substring(0, charIndex + 1));
                charIndex++;
            } else {
                clearInterval(typeInterval);
                // Pequena pausa antes de iniciar a barra para a pessoa terminar de ler
                setTimeout(startProgressBar, 800);
            }
        }, 40);
    }, 1500);

    // 3. Loading Bar
    const startProgressBar = () => {
        let filled = 0;
        const total = 20;
        // Aumentado para 250ms por bloco * 20 blocos = 5 segundos de loading
        const barInterval = setInterval(() => {
            filled++;
            const bar = "█".repeat(filled) + "▒".repeat(total - filled);
            setProgressText(`> Inicializando Preguiçoso OS... [${bar}]`);

            if (filled >= total) {
                clearInterval(barInterval);
                setProgressText("> Sistema Preguiçoso OS inicializado com sucesso.");
                
                // 4. Finish
                setTimeout(() => {
                    setIsFadingOut(true);
                    setTimeout(onFinish, 1000); // Wait for fade out transition
                }, 1500);
            }
        }, 250); 
    };

    return () => clearTimeout(typeTimer);
  }, [onFinish]);

  return (
    <div className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#0d0025] overflow-hidden transition-opacity duration-1000 ${isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
      <canvas ref={canvasRef} className="absolute inset-0 opacity-30" />
      <audio ref={audioRef} src="https://actions.google.com/sounds/v1/alarms/beep_short.ogg" />

      <div className="relative z-10 flex flex-col items-center max-w-2xl px-4 text-center">
        {/* Mascote */}
        <div className={`transition-all duration-1000 transform ${showImage ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <img 
                src="https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2FChatGPT%20Image%2022%20de%20nov.%20de%202025%2C%2007_28_47%20(2).png?alt=media&token=6efa1c33-7a90-4850-8b71-c8cd5ac6189c"
                alt="Preguiçoso OS" 
                className="w-40 sm:w-56 mb-8 drop-shadow-[0_0_15px_rgba(0,186,255,0.5)]"
                style={{ imageRendering: 'pixelated' }}
            />
        </div>

        {/* Texto Digitado */}
        <div className="h-20 mb-8">
            <p className="font-mono text-[#00baff] text-sm sm:text-lg whitespace-pre-line leading-relaxed drop-shadow-md">
                {text}
                <span className="animate-pulse">_</span>
            </p>
        </div>

        {/* Loading Bar */}
        <div className="font-mono text-[#ffd93d] text-xs sm:text-sm bg-black/50 p-2 rounded border border-[#ffd93d]/30 w-full max-w-md">
            {progressText || "> Aguardando input..."}
        </div>
      </div>
    </div>
  );
};