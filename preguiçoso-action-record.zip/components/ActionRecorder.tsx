import React, { useState, useRef, useEffect } from 'react';
import { Play, Square, Disc, Globe, MousePointer, Terminal, Save, RotateCcw, HelpCircle, X, List, Trash2, ShoppingCart, User, MessageSquare, AlertTriangle, Puzzle, Copy, Check, Download, ArrowRight, Code2, FileJson, Zap, Layers, RefreshCw, LayoutTemplate, FileCode, Package } from 'lucide-react';

interface RecordedAction {
  tipo: 'click' | 'input' | 'scroll' | 'change';
  seletor: string;
  valor?: string;
  tempo: number;
}

interface Workflow {
    id: string;
    name: string;
    date: string;
    actions: RecordedAction[];
    url: string;
}

interface ActionRecorderProps {
  onRecordingComplete: (json: string) => void;
}

// Cenários simulados para contornar limitações de Iframe (X-Frame-Options)
const SCENARIOS = {
    LOGIN: {
        url: 'https://portal.empresa.com/login',
        html: `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <style>
            body { font-family: 'Inter', sans-serif; background: #f3f4f6; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .card { background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); width: 320px; }
            h2 { color: #111827; margin-top: 0; font-size: 1.5rem; font-weight: 700; margin-bottom: 1.5rem; text-align: center; }
            .form-group { margin-bottom: 1rem; }
            label { display: block; font-size: 0.875rem; font-weight: 500; color: #374151; margin-bottom: 0.5rem; }
            input { width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.375rem; box-sizing: border-box; transition: all 0.2s; font-size: 0.875rem; }
            input:focus { border-color: #00baff; outline: none; ring: 2px solid rgba(0,186,255,0.2); }
            button { width: 100%; padding: 0.75rem; background: #00baff; color: white; border: none; border-radius: 0.375rem; font-weight: 600; cursor: pointer; transition: background 0.2s; margin-top: 1rem; }
            button:hover { background: #0095cc; }
            .msg { padding: 0.75rem; border-radius: 0.375rem; font-size: 0.875rem; margin-bottom: 1rem; display: none; }
            .success { background: #d1fae5; color: #065f46; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Portal Corporativo</h2>
            <div id="msg" class="msg success">Login realizado!</div>
            <div class="form-group"><label>Usuário</label><input type="email" id="email" data-testid="input-email" placeholder="user@company.com" /></div>
            <div class="form-group"><label>Senha</label><input type="password" id="password" data-testid="input-pass" placeholder="••••••" /></div>
            <button id="btn-action" data-testid="btn-login">Entrar no Sistema</button>
          </div>
          <script>
            document.getElementById('btn-action').addEventListener('click', () => {
               const btn = document.getElementById('btn-action');
               btn.innerText = "Autenticando...";
               setTimeout(() => {
                   btn.innerText = "Entrar no Sistema";
                   document.getElementById('msg').style.display = 'block';
               }, 600);
            });
          </script>
        </body>
        </html>`
    },
    ECOMMERCE: {
        url: 'https://loja.exemplo.com/produto/iphone-15',
        html: `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <style>
            body { font-family: 'Inter', sans-serif; background: #fff; padding: 20px; margin: 0; }
            .header { border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;}
            .product { display: flex; gap: 20px; }
            .img-placeholder { width: 150px; height: 200px; background: #eee; border-radius: 8px; display: flex; items-center; justify-content: center; color: #999; }
            .info { flex: 1; }
            h1 { margin: 0 0 10px 0; font-size: 1.5rem; }
            .price { font-size: 1.25rem; color: #16a34a; font-weight: bold; margin-bottom: 15px; }
            select { padding: 8px; margin-bottom: 15px; display: block; width: 100%; border: 1px solid #ddd; border-radius: 4px; }
            button { width: 100%; padding: 12px; background: #2563eb; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; }
            button:hover { background: #1d4ed8; }
            .cart-count { background: #ef4444; color: white; padding: 2px 6px; border-radius: 10px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="header">
             <strong>Minha Loja</strong>
             <span>Carrinho <span id="cart-badge" class="cart-count">0</span></span>
          </div>
          <div class="product">
            <div class="img-placeholder">FOTO</div>
            <div class="info">
                <h1>Smartphone Ultra Pro</h1>
                <div class="price">R$ 4.599,00</div>
                <label>Cor:</label>
                <select id="variant-select" name="color-selection">
                    <option value="black">Preto Espacial</option>
                    <option value="silver">Prata Lunar</option>
                </select>
                <button id="btn-add" aria-label="Adicionar ao Carrinho de Compras">Adicionar ao Carrinho</button>
            </div>
          </div>
          <script>
            let count = 0;
            document.getElementById('btn-add').addEventListener('click', () => {
               count++;
               document.getElementById('cart-badge').innerText = count;
               alert('Produto adicionado ao carrinho!');
            });
          </script>
        </body>
        </html>`
    },
    CONTACT: {
        url: 'https://suporte.sistema.com/novo-ticket',
        html: `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <style>
            body { font-family: 'Inter', sans-serif; background: #f8fafc; padding: 40px; margin: 0; display: flex; justify-content: center; }
            .form-container { background: white; padding: 30px; border-radius: 8px; width: 100%; max-width: 400px; border: 1px solid #e2e8f0; }
            h2 { margin-top: 0; color: #334155; }
            label { display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; }
            input, textarea, select { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #cbd5e1; border-radius: 4px; box-sizing: border-box; }
            textarea { height: 100px; resize: none; }
            button { background: #0f172a; color: white; padding: 12px; width: 100%; border: none; border-radius: 4px; cursor: pointer; font-weight: 600; }
            button:hover { background: #334155; }
          </style>
        </head>
        <body>
          <div class="form-container">
            <h2>Abrir Chamado</h2>
            <label>Departamento</label>
            <select id="dept">
                <option>Suporte Técnico</option>
                <option>Financeiro</option>
            </select>
            <label>Assunto</label>
            <input type="text" id="subject" name="assunto_ticket" placeholder="Ex: Erro no login" />
            <label>Descrição</label>
            <textarea id="desc" placeholder="Descreva o problema..."></textarea>
            <button id="btn-submit">Enviar Solicitação</button>
          </div>
          <script>
            document.getElementById('btn-submit').addEventListener('click', () => {
               const subj = document.getElementById('subject').value;
               if(!subj) alert('Por favor, preencha o assunto.');
               else alert('Chamado #9923 criado com sucesso!');
            });
          </script>
        </body>
        </html>`
    }
};

const EXTENSION_MANIFEST = `{
  "manifest_version": 3,
  "name": "Preguiçoso Recorder PRO",
  "version": "2.6.0",
  "description": "Extensão auxiliar do app Preguiçoso para copiar e EXECUTAR ações gravadas no navegador.",
  "permissions": [
    "storage",
    "scripting",
    "activeTab",
    "clipboardWrite"
  ],
  "host_permissions": ["<all_urls>"],
  "action": {
    "default_popup": "popup.html"
  },
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"]
    }
  ]
}`;

const EXTENSION_POPUP_HTML = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <style>
    body {
      background-color: #1a0033;
      color: #e0e0ff;
      font-family: 'Courier New', monospace;
      width: 300px;
      padding: 15px;
      margin: 0;
      border: 2px solid #2a004d;
    }
    
    /* Scanline Effect */
    body::before {
      content: " ";
      display: block;
      position: absolute;
      top: 0; left: 0; bottom: 0; right: 0;
      background: linear-gradient(to bottom, rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.1) 50%);
      background-size: 100% 4px;
      pointer-events: none;
      z-index: 10;
    }

    h1 { font-size: 16px; color: #00baff; text-transform: uppercase; margin: 0; text-align: center; text-shadow: 0 0 5px rgba(0, 186, 255, 0.5); }
    p.subtitle { font-size: 10px; color: #8a8ab5; margin: 0 0 15px 0; text-align: center; }

    /* TABS */
    .tabs { display: flex; gap: 5px; margin-bottom: 15px; border-bottom: 1px solid #2a004d; padding-bottom: 5px; }
    .tab-btn { flex: 1; background: transparent; border: none; color: #666; cursor: pointer; font-weight: bold; font-size: 12px; padding: 5px; text-transform: uppercase; }
    .tab-btn.active { color: #00baff; border-bottom: 2px solid #00baff; text-shadow: 0 0 5px rgba(0, 186, 255, 0.5); }

    .view { display: none; }
    .view.active { display: block; }

    button.action-btn {
      width: 100%; padding: 10px; margin-bottom: 10px; background: transparent;
      border: 1px solid #00baff; color: #00baff;
      font-family: inherit; font-size: 12px; font-weight: bold; text-transform: uppercase;
      cursor: pointer; transition: all 0.2s; border-radius: 4px;
    }
    button.action-btn:hover { background: rgba(0, 186, 255, 0.1); box-shadow: 0 0 10px rgba(0, 186, 255, 0.4); }
    
    button.secondary { border-color: #ff4ff0; color: #ff4ff0; }
    button.secondary:hover { background: rgba(255, 79, 240, 0.1); box-shadow: 0 0 10px rgba(255, 79, 240, 0.4); }

    button.run { border-color: #00ff00; color: #00ff00; margin-top: 10px; }
    button.run:hover { background: rgba(0, 255, 0, 0.1); box-shadow: 0 0 10px rgba(0, 255, 0, 0.4); }

    textarea {
        width: 100%; height: 80px; background: #0d001a; border: 1px solid #2a004d;
        color: #00ff00; font-size: 10px; padding: 5px; box-sizing: border-box;
        resize: none; font-family: monospace; outline: none;
    }
    textarea:focus { border-color: #00baff; }

    #mensagem {
      margin-top: 10px; font-size: 10px; color: #ffd93d; min-height: 20px;
      background: rgba(0,0,0,0.3); padding: 5px; border-radius: 4px; word-wrap: break-word;
    }

    footer { margin-top: 15px; text-align: center; font-size: 9px; color: #555; border-top: 1px solid #2a004d; padding-top: 5px; }
  </style>
</head>
<body>
  <h1>🚀 Preguiçoso</h1>
  <p class="subtitle">Recorder & Player v2.6</p>

  <div class="tabs">
    <button class="tab-btn active" data-target="viewGravar">Gravar</button>
    <button class="tab-btn" data-target="viewExecutar">Executar</button>
  </div>

  <!-- VIEW GRAVAR -->
  <div id="viewGravar" class="view active">
      <button id="btnCopiar" class="action-btn">📋 Copiar JSON</button>
      <button id="btnLimpar" class="action-btn secondary">🗑️ Limpar Memória</button>
  </div>

  <!-- VIEW EXECUTAR -->
  <div id="viewExecutar" class="view">
      <textarea id="jsonInput" placeholder='Cole o JSON aqui: [{"tipo":"click"...}]'></textarea>
      <button id="btnRun" class="action-btn run">▶️ Rodar no Site</button>
  </div>

  <div id="mensagem">Pronto.</div>

  <footer><small>Versão 2.6 — Araras Impressão 🦜</small></footer>
  <script src="popup.js"></script>
</body>
</html>`;

const EXTENSION_POPUP_JS = `// popup.js - Preguiçoso v2.6
const msgArea = document.getElementById("mensagem");

function setMsg(text, color = "#ffd93d") {
  msgArea.style.color = color;
  msgArea.innerText = text;
}

// --- TAB SWITCHING ---
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.target).classList.add('active');
    });
});

// --- GRAVAR: Copiar JSON ---
document.getElementById("btnCopiar").addEventListener("click", () => {
  chrome.storage.local.get("recordedActions", (data) => {
    if (!data.recordedActions || data.recordedActions.length === 0) {
      setMsg("⚠️ Nada gravado.", "#ff4444");
      return;
    }
    const json = JSON.stringify(data.recordedActions, null, 2);
    navigator.clipboard.writeText(json).then(() => {
      setMsg("✅ JSON copiado! Cole no App.");
    });
  });
});

// --- GRAVAR: Limpar ---
document.getElementById("btnLimpar").addEventListener("click", () => {
    chrome.storage.local.remove("recordedActions", () => {
        setMsg("🗑️ Memória limpa.", "#ff4ff0");
        // Avisa o content script para zerar a variável local também
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { action: "CLEAR_MEMORY" });
        });
    });
});

// --- EXECUTAR: Rodar JSON ---
document.getElementById("btnRun").addEventListener("click", () => {
    const rawJson = document.getElementById("jsonInput").value;
    if (!rawJson) { setMsg("❌ Cole o JSON primeiro.", "#ff4444"); return; }

    try {
        const actions = JSON.parse(rawJson);
        setMsg("🚀 Iniciando reprodução...", "#00ff00");
        
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { 
                action: "PLAY_ACTIONS", 
                data: actions 
            }, (response) => {
                if(chrome.runtime.lastError) {
                    setMsg("❌ Erro: Recarregue a página.", "#ff4444");
                }
            });
        });
    } catch (e) {
        setMsg("❌ JSON Inválido.", "#ff4444");
    }
});
`;

const EXTENSION_CONTENT_JS = `// content.js - Preguiçoso PRO v2.6
// Recorder + Player Engine

let actions = [];
const startTime = Date.now();

// --- 1. RECORDER LOGIC ---

if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get(['recordedActions'], (result) => {
        if (result.recordedActions) actions = result.recordedActions;
    });
}

function getOptimalSelector(el) {
  if (!el) return '';
  const qaAttrs = ['data-testid', 'data-cy', 'data-qa'];
  for (const attr of qaAttrs) if (el.hasAttribute(attr)) return \`[\${attr}="\${el.getAttribute(attr)}"]\`;
  if (el.id && el.id.length < 40 && !/\\d{5,}/.test(el.id)) return '#' + el.id;
  if (['button', 'a', 'label', 'span', 'h1'].includes(el.tagName.toLowerCase())) {
      const text = el.innerText ? el.innerText.trim() : '';
      if (text && text.length < 30) return \`text=\${text}\`;
  }
  if (el.name) return \`[name="\${el.name}"]\`;
  if (el.className) {
      const cleanClass = el.className.split(' ').find(c => c && !c.includes(':'));
      if(cleanClass) return '.' + cleanClass;
  }
  return el.tagName.toLowerCase();
}

function logAction(e) {
    if(!e.isTrusted || window.PREGUICOSO_IS_PLAYING) return; // Não grava se estiver tocando
    const target = e.target;
    const selector = getOptimalSelector(target);
    
    const action = {
        tipo: e.type,
        seletor: selector,
        valor: (target.value !== undefined) ? target.value : '',
        tempo: Date.now() - startTime
    };
    
    const last = actions[actions.length - 1];
    if (action.tipo === 'input' && last && last.seletor === action.seletor) {
        actions[actions.length - 1] = action;
    } else {
        actions.push(action);
    }
    chrome.storage.local.set({ recordedActions: actions });
}

['click', 'change', 'input'].forEach(evt => document.addEventListener(evt, logAction, true));

// --- 2. PLAYER ENGINE (REVERSE LOGIC) ---

window.PREGUICOSO_IS_PLAYING = false;

function findElementBySmartSelector(selector) {
    if (!selector) return null;
    
    // Seletor de Texto (text=Enviar)
    if (selector.startsWith('text=')) {
        const textToFind = selector.replace('text=', '').trim();
        const elements = document.querySelectorAll('button, a, span, div, label, h1, h2, h3');
        for (let el of elements) {
            if (el.innerText && el.innerText.trim() === textToFind) return el;
        }
        return null;
    }
    
    // Seletor CSS Padrão
    try {
        return document.querySelector(selector);
    } catch (e) {
        console.warn('Seletor inválido:', selector);
        return null;
    }
}

async function playActions(actionList) {
    window.PREGUICOSO_IS_PLAYING = true;
    console.log('▶️ PREGUICOSO PLAYER INICIADO');

    for (const act of actionList) {
        await new Promise(r => setTimeout(r, 800)); // Delay humano
        
        const el = findElementBySmartSelector(act.seletor);
        
        if (el) {
            // Highlight Visual
            const originalBox = el.style.boxShadow;
            const originalBorder = el.style.border;
            el.style.border = "2px solid #ff4ff0";
            el.style.boxShadow = "0 0 15px #ff4ff0";
            el.scrollIntoView({behavior: "smooth", block: "center"});

            console.log(\`Executando: \${act.tipo} em \${act.seletor}\`);

            if (act.tipo === 'click') {
                el.click();
            } else if (act.tipo === 'input' || act.tipo === 'change') {
                el.value = act.valor;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            }

            await new Promise(r => setTimeout(r, 300)); // Tempo do highlight
            el.style.boxShadow = originalBox;
            el.style.border = originalBorder;
        } else {
            console.error(\`❌ Elemento não encontrado: \${act.seletor}\`);
        }
    }
    
    alert('✅ Automação finalizada!');
    window.PREGUICOSO_IS_PLAYING = false;
}

// --- 3. MESSAGING ---

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "CLEAR_MEMORY") {
        actions = [];
        console.log("🧹 Memória limpa.");
    } else if (request.action === "PLAY_ACTIONS") {
        playActions(request.data);
    }
});

console.log('%c 🤖 PREGUIÇOSO PRO v2.6 (RECORDER + PLAYER) ', 'background: #1a0033; color: #00baff; font-weight:bold;');
`;

export const ActionRecorder: React.FC<ActionRecorderProps> = ({ onRecordingComplete }) => {
  const [mode, setMode] = useState<'SIMULATOR' | 'EXTENSION'>('SIMULATOR');
  
  // Simulator States
  const [url, setUrl] = useState(SCENARIOS.LOGIN.url);
  const [currentScenario, setCurrentScenario] = useState<keyof typeof SCENARIOS>('LOGIN');
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [currentActions, setCurrentActions] = useState<RecordedAction[]>([]);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [workflowName, setWorkflowName] = useState('');
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showSecurityAlert, setShowSecurityAlert] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const startTimeRef = useRef<number>(0);
  const isRecordingRef = useRef(false);

  // Extension States
  const [copiedManifest, setCopiedManifest] = useState(false);
  const [copiedContent, setCopiedContent] = useState(false);
  const [copiedPopupHtml, setCopiedPopupHtml] = useState(false);
  const [importedJson, setImportedJson] = useState('');

  // --- SIMULATOR LOGIC ---
  const addLog = (msg: string) => {
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev]);
  };

  const loadScenario = (scenarioKey: keyof typeof SCENARIOS) => {
      setCurrentScenario(scenarioKey);
      setUrl(SCENARIOS[scenarioKey].url);
      if (iframeRef.current) {
          iframeRef.current.srcdoc = SCENARIOS[scenarioKey].html;
      }
      addLog(`🔄 Cenário carregado: ${scenarioKey}`);
      setShowSecurityAlert(false);
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!Object.values(SCENARIOS).some(s => s.url === url)) {
          setShowSecurityAlert(true);
          addLog("⚠️ Erro: Tentativa de acesso a URL externa bloqueada pelo navegador.");
      } else {
          setShowSecurityAlert(false);
          reloadIframe();
      }
  };

  const reloadIframe = () => {
    if (iframeRef.current) {
      iframeRef.current.srcdoc = SCENARIOS[currentScenario].html;
      addLog('🔄 Simulador reiniciado.');
    }
  };

  const handleEvent = (e: Event) => {
      if (!isRecordingRef.current) return;

      const target = e.target as HTMLElement;
      
      let seletor = target.tagName.toLowerCase();
      if (target.getAttribute('data-testid')) seletor = `[data-testid="${target.getAttribute('data-testid')}"]`;
      else if (target.id) seletor = `#${target.id}`;
      else if ((target as any).name) seletor = `[name="${(target as any).name}"]`;
      else if (target.innerText && target.tagName === 'BUTTON') seletor = `text=${target.innerText}`;
      else if (target.className) seletor = `.${target.className.split(' ')[0]}`;
      
      if (['body', 'html', 'div.card', 'div.form-container', 'div.header'].includes(seletor)) return;

      const action: RecordedAction = {
        tipo: e.type as any,
        seletor,
        valor: (target as HTMLInputElement).value,
        tempo: Date.now() - startTimeRef.current
      };

      setCurrentActions(prev => {
        const last = prev[prev.length - 1];
        if (e.type === 'input' && last?.tipo === 'input' && last?.seletor === seletor) {
             const newArr = [...prev];
             newArr[newArr.length - 1] = action;
             return newArr;
        }
        return [...prev, action];
      });

      if (e.type !== 'input') addLog(`Capturado: ${e.type} em ${seletor}`);
  };

  const startRecording = () => {
    if (!iframeRef.current?.contentWindow) {
      reloadIframe();
      return;
    }
    setIsRecording(true);
    isRecordingRef.current = true;
    setCurrentActions([]);
    setLogs([]);
    startTimeRef.current = Date.now();
    addLog('🔴 REC: Gravação iniciada.');

    const doc = iframeRef.current.contentWindow.document;
    ['click', 'input', 'change'].forEach(evt => 
        doc.addEventListener(evt, handleEvent, true)
    );
  };

  const stopRecording = () => {
    setIsRecording(false);
    isRecordingRef.current = false;
    
    const doc = iframeRef.current?.contentWindow?.document;
    if(doc) {
        ['click', 'input', 'change'].forEach(evt => 
            doc.removeEventListener(evt, handleEvent, true)
        );
    }
    addLog('⏹️ REC: Gravação finalizada.');
    
    if(currentActions.length > 0) {
        setWorkflowName(`Fluxo ${currentScenario} #${workflows.length + 1}`);
        setShowSaveModal(true);
    }
  };

  const saveWorkflow = () => {
    const newWorkflow: Workflow = {
        id: Date.now().toString(),
        name: workflowName,
        date: new Date().toLocaleDateString(),
        actions: currentActions,
        url: url
    };
    setWorkflows([...workflows, newWorkflow]);
    setShowSaveModal(false);
    addLog(`💾 Fluxo "${workflowName}" salvo na biblioteca.`);
    onRecordingComplete(JSON.stringify(newWorkflow.actions, null, 2));
  };

  const playWorkflow = (flow: Workflow) => {
    if (!iframeRef.current?.contentWindow) return;

    const targetScenario = Object.entries(SCENARIOS).find(([k, v]) => v.url === flow.url);
    if(targetScenario) {
        if(SCENARIOS[currentScenario].url !== flow.url) {
             loadScenario(targetScenario[0] as any);
        } else {
             reloadIframe();
        }
    } else {
        reloadIframe();
    }

    setIsPlaying(true);
    addLog(`▶️ Executando fluxo: ${flow.name}...`);
    
    setTimeout(() => {
        const doc = iframeRef.current!.contentWindow!.document;
        flow.actions.forEach((action, index) => {
            setTimeout(() => {
                let el = null;
                if (action.seletor.startsWith('text=')) {
                     const text = action.seletor.replace('text=', '');
                     const all = Array.from(doc.querySelectorAll('button, a, span'));
                     el = all.find(e => (e as HTMLElement).innerText.trim() === text) as HTMLElement;
                } else {
                    try { el = doc.querySelector(action.seletor) as HTMLElement; } catch (e) {}
                }
                
                if (el) {
                    const originalBorder = el.style.border;
                    el.style.border = "2px solid #ff4ff0";
                    el.style.boxShadow = "0 0 10px rgba(255, 79, 240, 0.5)";
                    if (action.tipo === 'click') el.click();
                    else if (action.tipo === 'input' || action.tipo === 'change') {
                        if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement) {
                            el.value = action.valor || '';
                            el.dispatchEvent(new Event('input', { bubbles: true }));
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    }
                    addLog(`Executando: ${action.tipo} -> ${action.seletor}`);
                    setTimeout(() => {
                        el.style.border = originalBorder;
                        el.style.boxShadow = "none";
                    }, 300);
                }
                if (index === flow.actions.length - 1) {
                    setIsPlaying(false);
                    addLog(`✅ Fluxo "${flow.name}" concluído.`);
                }
            }, action.tempo + 600);
        });
    }, 500);
  };

  const deleteWorkflow = (id: string) => {
      setWorkflows(prev => prev.filter(w => w.id !== id));
  };

  // --- EXTENSION LOGIC ---
  const copyToClipboard = (text: string, setCopied: (val: boolean) => void) => {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (filename: string, content: string, mimeType: string) => {
      try {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (error) {
        alert('Erro ao gerar arquivo.');
      }
  };

  const processExtensionImport = () => {
      try {
          const json = JSON.parse(importedJson);
          onRecordingComplete(JSON.stringify(json, null, 2));
          setImportedJson('');
      } catch (e) {
          alert("JSON inválido. Copie exatamente o que a extensão gerou.");
      }
  };

  useEffect(() => {
      loadScenario('LOGIN');
      return () => { isRecordingRef.current = false; };
  }, []);

  const renderSimulator = () => (
    <div className="flex flex-col lg:flex-row gap-6 h-[700px]">
        <div className={`flex-grow flex flex-col bg-lazy-dark border-4 rounded-xl overflow-hidden shadow-2xl relative transition-all duration-300 ${isRecording ? 'border-red-500' : 'border-lazy-panel'}`}>
            <div className="bg-[#e0e0e0] px-4 py-2 flex flex-col gap-2 border-b border-gray-300">
                <div className="flex gap-2 mb-1">
                    <button onClick={() => loadScenario('LOGIN')} className={`flex items-center gap-2 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-wider transition-all ${currentScenario === 'LOGIN' ? 'bg-lazy-neonBlue text-white shadow-md' : 'bg-gray-300 text-gray-600 hover:bg-gray-400'}`}>
                        <User size={12}/> Login
                    </button>
                    <button onClick={() => loadScenario('ECOMMERCE')} className={`flex items-center gap-2 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-wider transition-all ${currentScenario === 'ECOMMERCE' ? 'bg-lazy-neonBlue text-white shadow-md' : 'bg-gray-300 text-gray-600 hover:bg-gray-400'}`}>
                        <ShoppingCart size={12}/> E-commerce
                    </button>
                    <button onClick={() => loadScenario('CONTACT')} className={`flex items-center gap-2 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-wider transition-all ${currentScenario === 'CONTACT' ? 'bg-lazy-neonBlue text-white shadow-md' : 'bg-gray-300 text-gray-600 hover:bg-gray-400'}`}>
                        <MessageSquare size={12}/> Formulário
                    </button>
                </div>
                <div className="flex items-center gap-4">
                    <div className="flex gap-1.5">
                        <div className="w-3 h-3 rounded-full bg-[#ff5f56]"></div>
                        <div className="w-3 h-3 rounded-full bg-[#ffbd2e]"></div>
                        <div className="w-3 h-3 rounded-full bg-[#27c93f]"></div>
                    </div>
                    <form onSubmit={handleUrlSubmit} className="flex-grow flex gap-2">
                        <div className="flex-grow bg-white rounded px-4 py-1.5 flex items-center gap-3 text-xs text-gray-600 font-mono shadow-sm border border-transparent focus-within:border-blue-400">
                            <Globe size={14} className="text-gray-400" />
                            <input 
                                value={url}
                                onChange={(e) => setUrl(e.target.value)}
                                className="bg-transparent border-none outline-none w-full text-gray-700 font-sans font-medium"
                                placeholder="Digite a URL..."
                            />
                        </div>
                    </form>
                    <button onClick={reloadIframe} className="text-gray-600 hover:text-black p-1 rounded hover:bg-gray-200 transition-colors" title="Recarregar">
                        <RotateCcw size={16} />
                    </button>
                </div>
            </div>
            <div className="flex-grow relative bg-[#f3f4f6]">
                {showSecurityAlert && (
                    <div className="absolute top-4 left-4 right-4 z-50 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded shadow-lg flex items-start gap-3 animate-fade-in">
                        <AlertTriangle className="flex-shrink-0" />
                        <div>
                            <p className="font-bold text-sm">Acesso Bloqueado pelo Navegador</p>
                            <p className="text-xs mt-1">Sites externos reais (como Google, G1, Facebook) bloqueiam ser abertos dentro de outros apps por segurança (X-Frame-Options). <br/><b>Solução:</b> Use os botões de "Cenários" acima para treinar o robô em ambientes simulados, ou troque para a aba "Modo Extensão".</p>
                        </div>
                        <button onClick={() => setShowSecurityAlert(false)}><X size={16}/></button>
                    </div>
                )}
                <iframe 
                    ref={iframeRef}
                    id="iframeSite"
                    title="Browser Simulator"
                    className="w-full h-full bg-white"
                    sandbox="allow-same-origin allow-scripts allow-forms allow-modals"
                />
                {isPlaying && (
                    <div className="absolute inset-0 bg-lazy-neonBlue/10 pointer-events-none flex items-center justify-center z-40">
                        <div className="bg-lazy-dark/90 text-lazy-neonBlue px-6 py-3 rounded-full font-bold border border-lazy-neonBlue animate-bounce flex items-center gap-2 shadow-xl">
                            <Play size={16} fill="currentColor" /> REPRODUZINDO FLUXO...
                        </div>
                    </div>
                )}
            </div>
        </div>
        <div className="w-full lg:w-80 flex flex-col gap-4">
            <div className="bg-lazy-panel/80 backdrop-blur border border-lazy-neonBlue/30 p-5 rounded-xl shadow-xl">
                <h3 className="text-xs font-bold text-lazy-neonBlue uppercase tracking-widest mb-3 flex items-center gap-2">
                    <Terminal size={12}/> Painel de Controle
                </h3>
                {!isRecording ? (
                    <button 
                        onClick={startRecording}
                        disabled={isPlaying}
                        className="w-full flex items-center justify-center gap-3 p-4 rounded-lg transition-all font-bold text-sm uppercase bg-red-500 hover:bg-red-600 text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105"
                    >
                        <Disc size={18} /> Iniciar Gravação
                    </button>
                ) : (
                    <button 
                        onClick={stopRecording}
                        className="w-full flex items-center justify-center gap-3 p-4 rounded-lg transition-all font-bold text-sm uppercase bg-lazy-text text-lazy-dark hover:bg-white animate-pulse"
                    >
                        <Square size={18} fill="currentColor" /> Parar & Salvar
                    </button>
                )}
            </div>
            <div className="flex-grow bg-lazy-dark border border-lazy-panel rounded-xl overflow-hidden flex flex-col shadow-inner min-h-[200px]">
                 <div className="bg-lazy-panel/50 px-4 py-3 border-b border-lazy-base flex items-center justify-between">
                    <span className="font-bold text-lazy-yellow uppercase tracking-widest text-xs flex items-center gap-2">
                        <List size={14}/> Biblioteca de Fluxos
                    </span>
                    <span className="bg-lazy-base text-lazy-text/50 text-[10px] px-2 py-0.5 rounded-full font-mono">
                        {workflows.length}
                    </span>
                 </div>
                 <div className="overflow-y-auto custom-scrollbar flex-grow p-2 space-y-2">
                    {workflows.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-lazy-text/20 text-center p-4">
                            <Save size={24} className="mb-2 opacity-50"/>
                            <p className="text-xs">Nenhum fluxo salvo.</p>
                            <p className="text-[10px] mt-1">Grave ações para criar sua biblioteca.</p>
                        </div>
                    ) : (
                        workflows.map((flow) => (
                            <div key={flow.id} className="bg-lazy-base/50 border border-lazy-text/10 hover:border-lazy-neonBlue/50 rounded-lg p-3 transition-all group">
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <h4 className="font-bold text-sm text-lazy-text group-hover:text-lazy-neonBlue truncate max-w-[140px]">{flow.name}</h4>
                                        <span className="text-[10px] text-lazy-text/40 font-mono block">{flow.date} • {flow.actions.length} steps</span>
                                        <span className="text-[9px] text-lazy-neonPink/60 font-mono truncate max-w-[140px] block">{flow.url.replace('https://', '')}</span>
                                    </div>
                                    <button onClick={() => deleteWorkflow(flow.id)} className="text-lazy-text/30 hover:text-red-500 transition-colors">
                                        <Trash2 size={14} />
                                    </button>
                                </div>
                                <button 
                                    onClick={() => playWorkflow(flow)}
                                    disabled={isRecording || isPlaying}
                                    className="w-full flex items-center justify-center gap-2 py-1.5 bg-lazy-neonBlue/10 hover:bg-lazy-neonBlue text-lazy-neonBlue hover:text-lazy-dark border border-lazy-neonBlue/30 rounded text-xs font-bold uppercase transition-all disabled:opacity-30"
                                >
                                    <Play size={12} fill="currentColor" /> Reproduzir
                                </button>
                            </div>
                        ))
                    )}
                 </div>
            </div>
            <div className="bg-black/40 rounded-xl p-3 font-mono text-[10px] h-32 overflow-y-auto custom-scrollbar border border-lazy-text/5">
                {logs.map((log, i) => (
                    <div key={i} className="text-lazy-text/60 mb-1 break-words">{log}</div>
                ))}
                {logs.length === 0 && <span className="text-lazy-text/20">Console de eventos...</span>}
            </div>
        </div>
    </div>
  );

  const renderExtensionMode = () => (
      <div className="flex flex-col lg:flex-row gap-8 h-[700px]">
          <div className="flex-1 bg-lazy-dark border-2 border-lazy-panel rounded-xl p-6 shadow-2xl overflow-y-auto custom-scrollbar">
              <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="text-xl font-bold text-lazy-yellow flex items-center gap-2">
                        <Puzzle className="text-lazy-yellow" /> KIT DE EXTENSÃO <span className="bg-lazy-neonPink text-lazy-dark text-[10px] px-1.5 py-0.5 rounded font-bold">v2.6 (PLAYER)</span>
                    </h3>
                    <p className="text-sm text-lazy-text/70 mt-1">
                        Instale para gravar E EXECUTAR em sites reais.
                    </p>
                  </div>
                  <div className="bg-green-500/20 border border-green-500 rounded px-3 py-2 text-[11px] font-bold text-green-200 animate-pulse flex items-center gap-2">
                    <RefreshCw size={14} /> NOVA VERSÃO DISPONÍVEL
                  </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
                  <div className="bg-lazy-base/50 p-3 rounded border border-lazy-text/10 flex items-start gap-3 group hover:border-lazy-neonBlue/30 transition-colors">
                      <LayoutTemplate className="text-lazy-neonBlue shrink-0 mt-0.5 group-hover:scale-110 transition-transform" size={16} />
                      <div>
                          <strong className="text-lazy-neonBlue text-xs uppercase block mb-1">Novo Modo Player</strong>
                          <p className="text-[10px] text-lazy-text/70">A extensão agora roda o script! Cole o JSON na aba 'Executar' e veja a mágica.</p>
                      </div>
                  </div>
                  <div className="bg-lazy-base/50 p-3 rounded border border-lazy-text/10 flex items-start gap-3 group hover:border-lazy-neonPink/30 transition-colors">
                       <Layers className="text-lazy-neonPink shrink-0 mt-0.5 group-hover:scale-110 transition-transform" size={16} />
                       <div>
                          <strong className="text-lazy-neonPink text-xs uppercase block mb-1">Smart Replay</strong>
                          <p className="text-[10px] text-lazy-text/70">O robô encontra botões pelo texto e destaca onde vai clicar.</p>
                      </div>
                  </div>
              </div>

              {/* Botão Download ZIP */}
              <div className="mb-8">
                  <a
                      href="https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fpreguicoso.zip?alt=media&token=109ade0f-7a8b-4026-9d7f-cbe24e7c59ac"
                      className="group relative block w-full overflow-hidden rounded-xl shadow-lg shadow-green-500/20"
                  >
                       <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-emerald-600 opacity-90 transition-opacity group-hover:opacity-100"></div>
                       <div className="relative flex items-center justify-center gap-3 p-4 text-black font-black tracking-widest uppercase">
                          <Package size={24} className="group-hover:animate-bounce" />
                          BAIXAR EXTENSÃO COMPLETA (ZIP)
                       </div>
                  </a>
                  <p className="text-[10px] text-center mt-2 text-lazy-text/50">
                      Alternativa rápida: Baixe o ZIP, extraia a pasta e carregue no Chrome.
                  </p>
              </div>

              <div className="space-y-6">
                  {/* MANIFEST.JSON */}
                  <div>
                      <div className="flex justify-between items-center mb-2 bg-lazy-panel px-3 py-2 rounded-t border border-lazy-text/10 border-b-0">
                          <span className="text-xs font-bold uppercase text-lazy-neonBlue flex items-center gap-2">
                              <FileJson size={14}/> manifest.json (v2.6)
                          </span>
                          <div className="flex gap-2">
                            <button onClick={() => copyToClipboard(EXTENSION_MANIFEST, setCopiedManifest)} className="text-[10px] flex items-center gap-1 text-lazy-text/60 hover:text-white px-2 py-1 hover:bg-lazy-dark rounded transition-colors">
                                {copiedManifest ? <Check size={12}/> : <Copy size={12}/>} {copiedManifest ? 'Copiado' : 'Copiar'}
                            </button>
                            <button onClick={() => downloadFile('manifest.json', EXTENSION_MANIFEST, 'application/json')} className="text-[10px] flex items-center gap-1 bg-lazy-neonBlue/20 text-lazy-neonBlue hover:bg-lazy-neonBlue hover:text-white px-2 py-1 rounded transition-colors border border-lazy-neonBlue/30">
                                <Download size={12}/> Baixar
                            </button>
                          </div>
                      </div>
                      <pre className="bg-black/50 p-4 rounded-b border border-lazy-text/10 text-xs text-green-400 font-mono overflow-x-auto max-h-32 custom-scrollbar">
                          {EXTENSION_MANIFEST}
                      </pre>
                  </div>

                  {/* POPUP FILES (NOVO) */}
                  <div className="grid grid-cols-2 gap-4">
                      <div>
                          <div className="flex justify-between items-center mb-2 bg-lazy-panel px-3 py-2 rounded-t border border-lazy-text/10 border-b-0">
                              <span className="text-xs font-bold uppercase text-lazy-neonPink flex items-center gap-2">
                                  <LayoutTemplate size={14}/> popup.html
                              </span>
                              <button onClick={() => downloadFile('popup.html', EXTENSION_POPUP_HTML, 'text/html')} className="text-[10px] flex items-center gap-1 bg-lazy-neonPink/20 text-lazy-neonPink hover:bg-lazy-neonPink hover:text-white px-2 py-1 rounded transition-colors border border-lazy-neonPink/30">
                                  <Download size={12}/> Baixar
                              </button>
                          </div>
                          <div className="bg-black/50 p-3 rounded-b border border-lazy-text/10 text-xs text-lazy-text/50 text-center italic h-20 flex items-center justify-center">
                             Interface com abas Gravar/Executar.
                          </div>
                      </div>
                      <div>
                          <div className="flex justify-between items-center mb-2 bg-lazy-panel px-3 py-2 rounded-t border border-lazy-text/10 border-b-0">
                              <span className="text-xs font-bold uppercase text-lazy-neonPink flex items-center gap-2">
                                  <FileCode size={14}/> popup.js
                              </span>
                              <button onClick={() => downloadFile('popup.js', EXTENSION_POPUP_JS, 'text/javascript')} className="text-[10px] flex items-center gap-1 bg-lazy-neonPink/20 text-lazy-neonPink hover:bg-lazy-neonPink hover:text-white px-2 py-1 rounded transition-colors border border-lazy-neonPink/30">
                                  <Download size={12}/> Baixar
                              </button>
                          </div>
                          <div className="bg-black/50 p-3 rounded-b border border-lazy-text/10 text-xs text-lazy-text/50 text-center italic h-20 flex items-center justify-center">
                             Lógica de Play/Stop do script.
                          </div>
                      </div>
                  </div>

                  {/* CONTENT.JS */}
                  <div>
                      <div className="flex justify-between items-center mb-2 bg-lazy-panel px-3 py-2 rounded-t border border-lazy-text/10 border-b-0">
                          <span className="text-xs font-bold uppercase text-lazy-yellow flex items-center gap-2">
                              <Code2 size={14}/> content.js (v2.6)
                          </span>
                          <div className="flex gap-2">
                             <button onClick={() => copyToClipboard(EXTENSION_CONTENT_JS, setCopiedContent)} className="text-[10px] flex items-center gap-1 text-lazy-text/60 hover:text-white px-2 py-1 hover:bg-lazy-dark rounded transition-colors">
                                {copiedContent ? <Check size={12}/> : <Copy size={12}/>} {copiedContent ? 'Copiado' : 'Copiar'}
                             </button>
                             <button onClick={() => downloadFile('content.js', EXTENSION_CONTENT_JS, 'text/javascript')} className="text-[10px] flex items-center gap-1 bg-lazy-yellow/20 text-lazy-yellow hover:bg-lazy-yellow hover:text-black px-2 py-1 rounded transition-colors border border-lazy-yellow/30 font-bold">
                                <Download size={12}/> Baixar
                             </button>
                          </div>
                      </div>
                      <pre className="bg-black/50 p-4 rounded-b border border-lazy-text/10 text-xs text-yellow-400 font-mono overflow-x-auto max-h-48 custom-scrollbar">
                          {EXTENSION_CONTENT_JS}
                      </pre>
                  </div>
              </div>
          </div>

          <div className="w-full lg:w-1/3 bg-lazy-panel/20 border-2 border-dashed border-lazy-text/20 rounded-xl p-6 flex flex-col">
               <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                   <Download className="text-white" /> Importar Gravação
               </h3>
               <p className="text-xs text-lazy-text/60 mb-4">
                   Cole aqui o JSON para enviar para o Robô de Cloud (Playwright).
               </p>
               
               <textarea 
                   value={importedJson}
                   onChange={(e) => setImportedJson(e.target.value)}
                   className="flex-grow bg-lazy-dark border border-lazy-text/10 rounded p-3 text-xs font-mono text-lazy-text mb-4 focus:border-lazy-neonBlue outline-none resize-none placeholder-lazy-text/20"
                   placeholder='[ { "tipo": "click", ... } ]'
               />

               <button 
                   onClick={processExtensionImport}
                   className="w-full py-3 bg-lazy-neonBlue text-lazy-dark font-bold rounded hover:bg-white transition-colors flex items-center justify-center gap-2 shadow-lg shadow-lazy-neonBlue/20"
               >
                   Processar Gravação <ArrowRight size={16} />
               </button>
          </div>
      </div>
  );

  return (
    <div className="w-full mt-12 animate-fade-in pb-12 relative">
        {showSaveModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm animate-fade-in">
                <div className="bg-lazy-panel border border-lazy-neonBlue p-6 rounded-xl w-96 shadow-2xl">
                    <h3 className="text-lg font-bold text-white mb-4">Salvar Fluxo de Automação</h3>
                    <input 
                        type="text" 
                        value={workflowName}
                        onChange={e => setWorkflowName(e.target.value)}
                        className="w-full bg-lazy-dark border border-lazy-text/30 rounded p-2 text-white mb-4 focus:border-lazy-neonBlue outline-none"
                        autoFocus
                    />
                    <div className="flex justify-end gap-2">
                        <button onClick={() => setShowSaveModal(false)} className="px-4 py-2 text-lazy-text hover:text-white">Descartar</button>
                        <button onClick={saveWorkflow} className="px-4 py-2 bg-lazy-neonBlue text-lazy-dark font-bold rounded hover:bg-white">Salvar</button>
                    </div>
                </div>
            </div>
        )}

        <div className="border-t-2 border-lazy-neonBlue/20 pt-8">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
                <div>
                    <h2 className="text-2xl font-black text-lazy-neonBlue mb-1 flex items-center gap-3 tracking-tighter">
                        <MousePointer className="animate-bounce" /> 
                        TREINAMENTO & SIMULAÇÃO
                    </h2>
                    <p className="text-sm text-lazy-text/60 font-mono pl-1 max-w-2xl">
                        Escolha o modo de operação do gravador.
                    </p>
                </div>
                
                <div className="flex flex-col items-center md:items-end gap-2">
                    <img 
                        src="https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Finstale.png?alt=media&token=29389354-52fe-4d51-8409-3f5aa13aa203"
                        className="h-11 object-contain animate-bounce cursor-pointer hover:scale-110 transition-transform drop-shadow-[0_0_10px_rgba(255,217,61,0.5)]"
                        alt="Instale a extensão"
                        onClick={() => setMode('EXTENSION')}
                    />
                    <div className="flex bg-lazy-dark p-1 rounded-lg border border-lazy-text/20">
                        <button 
                            onClick={() => setMode('SIMULATOR')}
                            className={`px-4 py-1.5 rounded text-xs font-bold uppercase transition-all flex items-center gap-2 ${mode === 'SIMULATOR' ? 'bg-lazy-neonBlue text-lazy-dark shadow' : 'text-lazy-text hover:bg-lazy-panel'}`}
                        >
                            <Globe size={14} /> Simulador (Iframe)
                        </button>
                        <button 
                            onClick={() => setMode('EXTENSION')}
                            className={`px-4 py-1.5 rounded text-xs font-bold uppercase transition-all flex items-center gap-2 ${mode === 'EXTENSION' ? 'bg-lazy-yellow text-lazy-dark shadow' : 'text-lazy-text hover:bg-lazy-panel'}`}
                        >
                            <Puzzle size={14} /> Kit Extensão PRO
                        </button>
                    </div>
                </div>
            </div>

            {mode === 'SIMULATOR' ? renderSimulator() : renderExtensionMode()}
        </div>
    </div>
  );
}