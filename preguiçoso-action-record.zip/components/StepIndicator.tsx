import React from 'react';
import { AppStep } from '../types';
import { Settings, Terminal, Cpu } from 'lucide-react';

interface StepIndicatorProps {
  currentStep: AppStep;
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({ currentStep }) => {
  const getStepStatus = (step: AppStep, target: AppStep) => {
    const order = [AppStep.CONFIG, AppStep.SCRIPT_GEN, AppStep.INFRA_PREVIEW];
    const currentIndex = order.indexOf(currentStep);
    const targetIndex = order.indexOf(target);
    
    if (currentIndex === targetIndex) return 'current';
    if (currentIndex > targetIndex) return 'completed';
    return 'pending';
  };

  const steps = [
    { id: AppStep.CONFIG, label: 'ENTRADAS', icon: Settings },
    { id: AppStep.SCRIPT_GEN, label: 'PLAYBOOK', icon: Terminal },
    { id: AppStep.INFRA_PREVIEW, label: 'EXECUÇÃO', icon: Cpu },
  ];

  return (
    <div className="flex justify-center items-center w-full mb-12 relative z-10">
      {steps.map((step, idx) => {
        const status = getStepStatus(currentStep, step.id);
        const Icon = step.icon;
        
        return (
          <div key={step.id} className="flex items-center">
            <div className={`flex flex-col items-center gap-3 relative group`}>
              
              {/* Hexagon/Pixel Shape */}
              <div className={`w-14 h-14 flex items-center justify-center transition-all duration-300 transform border-2 skew-x-[-10deg]
                ${status === 'current' 
                  ? 'bg-lazy-neonBlue/20 border-lazy-neonBlue shadow-[0_0_20px_rgba(0,186,255,0.4)] scale-110' 
                  : status === 'completed' 
                    ? 'bg-lazy-neonPink/20 border-lazy-neonPink shadow-[0_0_10px_rgba(255,79,240,0.3)]' 
                    : 'bg-lazy-dark border-lazy-panel text-gray-600'}`}>
                
                <Icon 
                  size={24} 
                  className={`transform skew-x-[10deg] ${
                    status === 'current' ? 'text-lazy-neonBlue animate-pulse' : 
                    status === 'completed' ? 'text-lazy-neonPink' : 'text-gray-600'
                  }`} 
                />
              </div>

              {/* Label */}
              <span className={`text-xs font-bold tracking-widest transform ${
                status === 'current' ? 'text-lazy-neonBlue drop-shadow-[0_0_5px_rgba(0,186,255,0.8)]' : 
                status === 'completed' ? 'text-lazy-neonPink' : 'text-gray-600'
              }`}>
                {step.label}
              </span>
            </div>

            {/* Connector Line */}
            {idx < steps.length - 1 && (
              <div className="flex flex-col gap-1 mx-4">
                 <div className={`w-16 h-1 rounded-none transition-all duration-500
                  ${status === 'completed' ? 'bg-lazy-neonPink shadow-[0_0_10px_rgba(255,79,240,0.5)]' : 'bg-lazy-panel'}`} 
                />
                <div className={`w-16 h-1 rounded-none transition-all duration-500 delay-75
                  ${status === 'completed' ? 'bg-lazy-neonPink/50' : 'bg-lazy-panel/30'}`} 
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};