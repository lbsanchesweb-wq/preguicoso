
import React, { useEffect, useRef, useState } from 'react';
import { X, RotateCcw } from 'lucide-react';

interface GalacticGameProps {
  onClose: () => void;
}

export const GalacticGame: React.FC<GalacticGameProps> = ({ onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  
  // Ref para expor a função de reset para fora do useEffect
  const resetGameRef = useRef<() => void>(() => {});

  // Refs para controlar o loop de jogo sem depender de re-renders do React
  const gameState = useRef({
    running: true,
    frames: 0,
    map: [] as any[],
    player: {
        gridX: 4, gridY: 0,
        x: 4, y: 0, z: 0,
        isMoving: false, moveProgress: 0,
        targetX: 4, targetY: 0,
        startX: 4, startY: 0,
        facing: 'up'
    },
    camX: 0,
    camY: 0
  });

  useEffect(() => {
    const stored = localStorage.getItem('preguicoso_highscore');
    if (stored) setHighScore(parseInt(stored));

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Carregar Sprite do Personagem
    const characterImg = new Image();
    characterImg.src = "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2FChatGPT%20Image%2022%20de%20nov.%20de%202025%2C%2014_25_55%20(2).png?alt=media&token=39c17e6b-51ce-42dd-893f-d472d2d9e75f";

    // --- CONSTANTS & CONFIG ---
    const TILE_SIZE = 40;
    const TILE_HEIGHT = 22; 
    const MAP_WIDTH = 9;
    const BUFFER_SIZE = 50; // Buffer inicial maior

    // Nova Paleta: Cidade / Crossy Road Style
    const PALETTE = {
        bg: '#87CEEB',        // Céu Azul
        grass: '#7ebd40',     // Grama Lateral
        grassTop: '#89cc4b',  // Grama Topo
        road: '#555555',      // Asfalto Base
        roadTop: '#666666',   // Asfalto Topo
        sidewalk: '#d1d5db',
        
        // Obstáculos (Monitores/PCs)
        monitorCase: '#e5e7eb',
        monitorScreen: '#1d4ed8', // Tela azul da morte
        monitorStand: '#9ca3af'
    };

    // --- UTILS ---
    function resetGame() {
        gameState.current.running = true;
        gameState.current.frames = 0;
        gameState.current['score'] = 0; // Score interno
        gameState.current.map = [];
        gameState.current.camX = 0; // Reset camera X
        gameState.current.camY = 0; // Reset camera Y
        
        // Reset Player
        gameState.current.player = {
            gridX: Math.floor(MAP_WIDTH / 2),
            gridY: 0,
            x: Math.floor(MAP_WIDTH / 2),
            y: 0,
            z: 0,
            isMoving: false,
            moveProgress: 0,
            targetX: Math.floor(MAP_WIDTH / 2),
            targetY: 0,
            startX: Math.floor(MAP_WIDTH / 2),
            startY: 0,
            facing: 'up'
        };
        
        // Init Map (Gerar bastante terreno inicial)
        for (let i = -5; i < BUFFER_SIZE; i++) {
            gameState.current.map.push(generateRow(i));
        }
        
        setScore(0);
        setGameOver(false);
        
        // Reinicia o loop se estiver parado
        requestAnimationFrame(loop);
    }
    
    // Conecta a função interna ao Ref externo
    resetGameRef.current = resetGame;
    
    // Adiciona score ao gameState para acesso síncrono
    gameState.current['score'] = 0;

    const resize = () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    // --- ISOMETRIC PROJECTION ---
    function iso(x: number, y: number, z: number = 0) {
        const camX = gameState.current.camX;
        const camY = gameState.current.camY;
        return {
            x: (x - y) * TILE_SIZE + canvas!.width / 2 - camX,
            y: (x + y) * TILE_HEIGHT / 2 - (z * TILE_SIZE) + canvas!.height / 2 - camY
        };
    }

    function shadeColor(color: string, percent: number) {
        // Simulação simples de sombra (Hardcoded mappings para performance)
        if (color === PALETTE.grassTop) return PALETTE.grass;
        if (color === PALETTE.roadTop) return PALETTE.road;
        if (color === PALETTE.monitorCase) return '#9ca3af'; 
        return color;
    }

    // --- DRAWING PRIMITIVES ---
    function drawCube(gx: number, gy: number, gz: number, color: string, heightVal: number, widthScale = 1, depthScale = 1) {
        const pos = iso(gx, gy, gz);
        const x = pos.x;
        const y = pos.y;
        
        const ts = TILE_SIZE * widthScale;
        const th = TILE_HEIGHT * depthScale;

        // Face Superior
        ctx!.fillStyle = color;
        ctx!.beginPath();
        ctx!.moveTo(x, y - heightVal);
        ctx!.lineTo(x + ts, y - th / 2 - heightVal);
        ctx!.lineTo(x, y - th - heightVal);
        ctx!.lineTo(x - ts, y - th / 2 - heightVal);
        ctx!.fill();

        // Face Direita
        ctx!.fillStyle = shadeColor(color, -20);
        ctx!.beginPath();
        ctx!.moveTo(x + ts, y - th / 2 - heightVal);
        ctx!.lineTo(x, y - heightVal);
        ctx!.lineTo(x, y);
        ctx!.lineTo(x + ts, y - th / 2);
        ctx!.fill();

        // Face Esquerda
        ctx!.fillStyle = shadeColor(color, -40);
        ctx!.beginPath();
        ctx!.moveTo(x - ts, y - th / 2 - heightVal);
        ctx!.lineTo(x, y - heightVal);
        ctx!.lineTo(x, y);
        ctx!.lineTo(x - ts, y - th / 2);
        ctx!.fill();
    }

    // --- SPECIFIC DRAWING ---

    function drawSloth(x: number, y: number, z: number) {
        // Desenhar Sprite do Personagem (Imagem)
        const pos = iso(x, y, z);
        
        // Tamanho do sprite na tela (ajustado para parecer proporcional ao tile)
        const spriteSize = 70; 
        
        if (characterImg.complete) {
            ctx!.drawImage(
                characterImg,
                pos.x - spriteSize / 2, // Centralizar horizontalmente
                pos.y - spriteSize + 10, // Posicionar base no chão (com leve ajuste)
                spriteSize,
                spriteSize
            );
        } else {
            // Fallback enquanto carrega: Cubo simples
            drawCube(x, y, z, '#8D6E63', 10);
        }
    }

    function drawMonitor(x: number, y: number, z: number) {
        // Base
        drawCube(x, y, z, PALETTE.monitorStand, 5);
        // Carcaça
        drawCube(x, y, z + 0.2, PALETTE.monitorCase, 25);
        // Tela (Deslocada um pouco pra 'frente' visualmente em X)
        drawCube(x - 0.1, y, z + 0.5, PALETTE.monitorScreen, 18);
    }

    // --- GENERATION LOGIC ---
    function generateRow(yIndex: number) {
        // Regra: Primeiras linhas seguras. Depois aleatório.
        let type = 'safe';
        if (yIndex > 3) {
            // 50% chance de estrada (diminuído de 60%)
            type = Math.random() > 0.5 ? 'road' : 'safe';
        }

        // Se a anterior foi road, chance moderada de ser road de novo (faixas duplas)
        const prevRow = gameState.current.map[gameState.current.map.length - 1];
        if (prevRow && prevRow.type === 'road' && Math.random() > 0.6) type = 'road';

        // Evitar mais de 3 estradas seguidas
        let roadsInRow = 0;
        for(let i = gameState.current.map.length-1; i>=0; i--) {
            if (gameState.current.map[i].type === 'road') roadsInRow++;
            else break;
        }
        if (roadsInRow >= 3) type = 'safe';

        // Velocidade Reduzida (Mais lento)
        // Antes: 0.015 (base)
        const baseSpeed = 0.008; 
        const randomSpeed = Math.random() * 0.01;
        const speed = (baseSpeed + randomSpeed) * (Math.random() > 0.5 ? 1 : -1); 

        return {
            type,
            y: yIndex,
            obstacles: [],
            speed: speed 
        };
    }

    // Init (Chamado uma vez)
    resetGame();

    // --- GAME LOOP ---
    function update() {
        if (!gameState.current.running) return;
        const st = gameState.current;

        st.frames++;
        
        // 1. Player Logic
        if (st.player.isMoving) {
            // Pulo mais lento (0.10)
            st.player.moveProgress += 0.10;
            
            if (st.player.moveProgress >= 1) {
                st.player.isMoving = false;
                st.player.moveProgress = 0;
                st.player.x = st.player.targetX;
                st.player.y = st.player.targetY;
                st.player.gridX = Math.round(st.player.targetX);
                st.player.gridY = Math.round(st.player.targetY);
                
                // Update Score
                const currentScore = Math.max(st['score'], st.player.gridY);
                if (currentScore > st['score']) {
                    st['score'] = currentScore;
                    setScore(currentScore);
                }

            } else {
                // Lerp Linear
                const t = st.player.moveProgress;
                st.player.x = st.player.startX + (st.player.targetX - st.player.startX) * t;
                st.player.y = st.player.startY + (st.player.targetY - st.player.startY) * t;
                
                // Arco do Pulo (Senoide)
                st.player.z = Math.sin(t * Math.PI) * 1.5; 
            }
        }

        // 2. Camera Follow (AGORA CORRIGIDA PARA X E Y)
        // Calcula onde o jogador está na projeção isométrica
        const isoPlayerX = (st.player.x - st.player.y) * TILE_SIZE;
        const isoPlayerY = (st.player.x + st.player.y) * TILE_HEIGHT / 2;

        // Define o alvo da câmera:
        // X = Posição isométrica X do player
        // Y = Posição isométrica Y do player - 150px (para ele ficar mais pra baixo na tela)
        const targetCamX = isoPlayerX;
        const targetCamY = isoPlayerY - 150; 

        // Interpolação suave para X e Y
        st.camX += (targetCamX - st.camX) * 0.1;
        st.camY += (targetCamY - st.camY) * 0.1;

        // 3. Obstacles Logic
        const visibleRows = st.map.filter(row => row.y > st.player.gridY - 10 && row.y < st.player.gridY + 20);
        
        visibleRows.forEach(row => {
            if (row.type === 'road') {
                // Spawn Rate Reduzido
                if (Math.random() < 0.005) { 
                    // Verifica sobreposição básica
                    const tooClose = row.obstacles.some((o: any) => {
                        const spawnX = row.speed > 0 ? -3 : MAP_WIDTH + 3;
                        return Math.abs(o.realX - spawnX) < 4; // Espaçamento mínimo maior (antes 3)
                    });

                    if (!tooClose) {
                        row.obstacles.push({
                            realX: row.speed > 0 ? -3 : MAP_WIDTH + 3,
                            x: 0 // Visual X
                        });
                    }
                }

                // Move
                row.obstacles.forEach((obs: any) => {
                    obs.realX += row.speed;
                    obs.x = obs.realX;
                });

                // Cleanup
                row.obstacles = row.obstacles.filter((o: any) => o.realX > -5 && o.realX < MAP_WIDTH + 5);

                // Collision Check (Bounding Box Simples)
                if (Math.round(st.player.y) === row.y && st.player.z < 0.5) { // Só bate se tiver baixo
                     row.obstacles.forEach((obs: any) => {
                         if (Math.abs(obs.realX - st.player.x) < 0.7) {
                             endGame();
                         }
                     });
                }
            }
        });

        // Infinite Gen (Aggressive)
        const lastRow = st.map[st.map.length - 1];
        // Garante que sempre há 40 linhas à frente
        if (lastRow.y < st.player.gridY + 40) {
            st.map.push(generateRow(lastRow.y + 1));
            // Cleanup old rows (keep history sane)
            if (st.map.length > 150) st.map.shift();
        }
    }

    function draw() {
        const st = gameState.current;
        
        // Background Sky
        ctx!.fillStyle = PALETTE.bg;
        ctx!.fillRect(0, 0, canvas!.width, canvas!.height);

        // Render Rows (Painter's Algorithm)
        // Filter visible range (increased draw distance)
        const renderList = st.map.filter(r => r.y > st.player.gridY - 12 && r.y < st.player.gridY + 30);

        renderList.forEach(row => {
            // 1. Floor
            for (let x = -1; x <= MAP_WIDTH; x++) {
                const isSidewalk = x < 0 || x === MAP_WIDTH;
                let color = row.type === 'road' ? PALETTE.roadTop : PALETTE.grassTop;
                if (isSidewalk) color = PALETTE.sidewalk;
                
                // Estrada um pouco mais baixa que grama pra dar profundidade
                const h = row.type === 'road' && !isSidewalk ? 2 : 5; 
                
                drawCube(x, row.y, -0.5, color, h);
            }

            // 2. Obstacles (Monitors)
            if (row.type === 'road') {
                row.obstacles.forEach((obs: any) => {
                    drawMonitor(obs.x, row.y, 0);
                });
            }

            // 3. Player (If on this row)
            if (Math.round(st.player.y) === row.y) {
                // Sombra
                if (st.player.z > 0.1) {
                    // Sombra simples redonda
                    const shadowPos = iso(st.player.x, st.player.y, -0.4);
                    ctx!.fillStyle = 'rgba(0,0,0,0.3)';
                    ctx!.beginPath();
                    ctx!.ellipse(shadowPos.x + TILE_SIZE/2, shadowPos.y - TILE_HEIGHT/2, 15, 8, 0, 0, Math.PI*2);
                    ctx!.fill();
                }
                drawSloth(st.player.x, st.player.y, st.player.z);
            }
        });
    }

    function loop() {
        if (!gameState.current.running) return;
        update();
        draw();
        requestAnimationFrame(loop);
    }

    function endGame() {
        gameState.current.running = false;
        setGameOver(true);
        
        const current = gameState.current['score'];
        const saved = parseInt(localStorage.getItem('preguicoso_highscore') || '0');
        if (current > saved) {
            localStorage.setItem('preguicoso_highscore', current.toString());
            setHighScore(current);
        }
    }

    function move(dx: number, dy: number) {
        const p = gameState.current.player;
        if (p.isMoving || !gameState.current.running) return;

        const nextX = p.gridX + dx;
        const nextY = p.gridY + dy;

        if (nextX < 0 || nextX >= MAP_WIDTH) return; // Paredes laterais
        if (nextY < p.gridY - 2) return; // Não voltar muito

        p.startX = p.gridX;
        p.startY = p.gridY;
        p.targetX = nextX;
        p.targetY = nextY;
        p.isMoving = true;
        p.moveProgress = 0;
    }

    // --- EVENT LISTENERS ---
    const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'ArrowUp' || e.key === 'w') move(0, 1);
        if (e.key === 'ArrowDown' || e.key === 's') move(0, -1);
        if (e.key === 'ArrowLeft' || e.key === 'a') move(-1, 0);
        if (e.key === 'ArrowRight' || e.key === 'd') move(1, 0);
    };

    let touchStartX = 0;
    let touchStartY = 0;
    const handleTouchStart = (e: TouchEvent) => {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
    };
    const handleTouchEnd = (e: TouchEvent) => {
        const dx = e.changedTouches[0].clientX - touchStartX;
        const dy = e.changedTouches[0].clientY - touchStartY;
        
        if (Math.abs(dx) > Math.abs(dy)) {
            move(dx > 0 ? 1 : -1, 0);
        } else {
            move(0, dy < 0 ? 1 : -1); // Swipe Up = Avançar
        }
    };

    window.addEventListener('keydown', handleKeyDown);
    canvas?.addEventListener('touchstart', handleTouchStart);
    canvas?.addEventListener('touchend', handleTouchEnd);

    // Start Loop
    const animId = requestAnimationFrame(loop);

    return () => {
        gameState.current.running = false;
        cancelAnimationFrame(animId);
        window.removeEventListener('resize', resize);
        window.removeEventListener('keydown', handleKeyDown);
        canvas?.removeEventListener('touchstart', handleTouchStart);
        canvas?.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  // RESTART INTERNO (Sem reload da página)
  const handleRestart = () => {
      resetGameRef.current();
  };

  return (
    <div className="fixed inset-0 z-[100] bg-sky-900/90 flex flex-col items-center justify-center backdrop-blur-sm animate-fade-in font-mono">
       <button onClick={onClose} className="absolute top-4 right-4 text-white hover:scale-110 transition-transform z-50 bg-black/20 rounded-full p-2">
           <X size={24} />
       </button>

       {/* HUD */}
       <div className="absolute top-8 flex gap-4 z-40">
            <div className="bg-white/90 border-b-4 border-black/20 px-6 py-2 rounded-xl shadow-xl text-center min-w-[100px]">
                <p className="text-[10px] text-gray-500 font-bold uppercase">SCORE</p>
                <p className="text-3xl font-black text-sky-600">{score}</p>
            </div>
            <div className="bg-yellow-400/90 border-b-4 border-black/20 px-6 py-2 rounded-xl shadow-xl text-center min-w-[100px]">
                <p className="text-[10px] text-yellow-800 font-bold uppercase">BEST</p>
                <p className="text-2xl font-black text-white drop-shadow-md">{highScore}</p>
            </div>
       </div>

       {/* GAME OVER */}
       {gameOver && (
           <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/60 backdrop-blur-md animate-bounce-in p-4">
               <div className="bg-white p-8 rounded-2xl shadow-2xl text-center max-w-sm w-full border-b-8 border-gray-300">
                   <h3 className="text-4xl font-black text-gray-800 mb-2">BATIDÃO!</h3>
                   <p className="text-gray-500 mb-6 text-sm">A preguiça encontrou um monitor.</p>
                   
                   <div className="bg-sky-100 p-4 rounded-xl mb-6">
                        <p className="text-xs text-sky-600 font-bold uppercase">Sua Pontuação</p>
                        <p className="text-6xl font-black text-sky-500">{score}</p>
                   </div>

                   <button 
                       onClick={handleRestart} 
                       className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-6 rounded-xl uppercase tracking-widest transition-all shadow-lg border-b-4 border-green-700 active:border-b-0 active:translate-y-1 flex items-center justify-center gap-2"
                   >
                       <RotateCcw size={20}/> Tentar De Novo
                   </button>
               </div>
           </div>
       )}

       <canvas ref={canvasRef} className="block w-full h-full cursor-pointer touch-none" />
       
       {!gameOver && (
           <div className="absolute bottom-8 text-white/50 text-xs font-bold animate-pulse pointer-events-none bg-black/20 px-4 py-2 rounded-full">
               SWIPE ou SETAS para pular
           </div>
       )}
    </div>
  );
};
