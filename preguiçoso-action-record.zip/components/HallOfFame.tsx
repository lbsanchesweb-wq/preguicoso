import React from 'react';
import { Trophy, Star } from 'lucide-react';

const CONTRIBUTORS = [
  {
    id: 1,
    name: '@AnonyMaster',
    avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=AnonyMaster',
    points: 932,
    color: 'text-lazy-neonBlue'
  },
  {
    id: 2,
    name: '@Flanpull',
    avatar: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Flanpull',
    points: 870,
    color: 'text-lazy-neonPink'
  },
  {
    id: 3,
    name: '@Kilian_jornada',
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
    points: 845,
    color: 'text-lazy-yellow'
  },
  {
    id: 4,
    name: '---',
    avatar: 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=', // Transparent Image
    points: 0,
    color: 'text-gray-600'
  },
  {
    id: 5,
    name: '@SleepyRoot',
    avatar: 'https://api.dicebear.com/7.x/fun-emoji/svg?seed=SleepyRoot',
    points: 790,
    color: 'text-purple-400'
  }
];

export const HallOfFame: React.FC = () => {
  return (
    <section className="w-full mt-16 mb-24 border-t border-lazy-neonBlue/20 pt-8 relative animate-fade-in">
      {/* Glow Effect Top */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-gradient-to-r from-transparent via-lazy-neonBlue to-transparent opacity-50 blur-sm"></div>

      <div className="flex items-center justify-center gap-3 mb-6">
        <Trophy className="text-lazy-yellow animate-pulse" size={24} />
        <h3 className="text-center text-lazy-neonBlue font-mono text-sm sm:text-base font-bold uppercase tracking-[0.2em] drop-shadow-[0_0_5px_rgba(0,186,255,0.5)]">
          Hall da Fama dos Preguiçosos
        </h3>
        <Trophy className="text-lazy-yellow animate-pulse" size={24} />
      </div>

      {/* Horizontal Scroll Container */}
      <div className="relative w-full overflow-hidden group">
        <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-lazy-base to-transparent z-10 pointer-events-none"></div>
        <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-lazy-base to-transparent z-10 pointer-events-none"></div>
        
        <div className="flex overflow-x-auto gap-5 px-6 pb-6 pt-2 custom-scrollbar snap-x snap-mandatory">
          {CONTRIBUTORS.map((user) => (
            <div 
              key={user.id}
              className="snap-center min-w-[200px] max-w-[200px] bg-lazy-panel/40 backdrop-blur-sm border border-lazy-neonBlue/30 rounded-xl p-4 shadow-[0_0_10px_rgba(0,0,0,0.3)] hover:shadow-[0_0_15px_rgba(0,186,255,0.2)] hover:-translate-y-1 transition-all duration-300 flex flex-col items-center relative group/card"
            >
              {/* Rank Badge */}
              <div className="absolute top-2 left-2 text-[10px] font-bold bg-lazy-dark px-1.5 py-0.5 rounded border border-lazy-text/10 text-lazy-text/50">
                #{user.id}
              </div>

              {/* Avatar */}
              <div className="relative mb-3">
                 <div className={`absolute inset-0 rounded-full blur opacity-40 ${user.color.replace('text-', 'bg-')}`}></div>
                 <img 
                    src={user.avatar} 
                    alt={user.name} 
                    className={`w-14 h-14 rounded-full border-2 p-0.5 bg-lazy-dark relative z-10 object-cover ${user.color.replace('text-', 'border-')}`}
                 />
              </div>

              {/* Info */}
              <p className={`font-mono text-xs font-bold mb-2 ${user.color}`}>{user.name}</p>
              
              <div className="flex items-center gap-1 bg-lazy-dark/80 px-2 py-1 rounded-full border border-lazy-yellow/20 mb-4">
                <Star size={10} className="text-lazy-yellow fill-lazy-yellow" />
                <span className="text-lazy-yellow text-[10px] font-bold">{user.points} pts</span>
              </div>

              {/* Social Links */}
              <div className="flex gap-4 mt-auto opacity-60 group-hover/card:opacity-100 transition-opacity">
                 <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform" title="GitHub">
                    <img src="https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fgithub.png?alt=media&token=6afd461f-1bdf-49fb-b207-c63a62389c14" alt="GitHub" className="w-4 h-4" />
                 </a>
                 <a href="https://reddit.com" target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform" title="Reddit">
                     <img src="https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Freddit.png?alt=media&token=4c8b612e-56ee-4395-8d28-8acc510e75ae" alt="Reddit" className="w-4 h-4" />
                 </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
