import React, { useEffect, useRef } from 'react';

export const PixelBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Configuração de imagens
    const iconPaths = [
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Farcade-machine.png?alt=media&token=7f857bbc-593e-42f0-b837-24b8275a6998",
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fhand%20(1).png?alt=media&token=fa01e225-df5d-44ab-96cd-8b3a4141bf3e",
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fhand.png?alt=media&token=8537645e-ed2a-4f49-8640-130811737e8f",
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fmail.png?alt=media&token=d3f461da-3f99-4da7-b431-7d67a80303f4",
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fprofit.png?alt=media&token=8d6c4246-bfcd-4c68-acb7-21c0ac08a421",
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Frobot.png?alt=media&token=a8f8e624-960a-4989-8505-64af9d3ef404",
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fstart-up.png?alt=media&token=ba022d09-b1d7-4df1-b080-146b444aa678",
      "https://firebasestorage.googleapis.com/v0/b/volta-as-aulas-2026.firebasestorage.app/o/action-record%2Fwebsite.png?alt=media&token=32c45970-5b2f-4252-8685-e5df63d0b36a"
    ];

    interface IconEntity {
      img: HTMLImageElement;
      isRocket: boolean;
      x: number;
      y: number;
      dx: number;
      dy: number;
      size: number;
      opacity: number;
      opacitySpeed: number;
    }

    const icons: IconEntity[] = [];
    
    // Multiplicador de densidade: 5x mais ícones
    const DENSITY_MULTIPLIER = 5;

    // Inicializar ícones (repetindo o loop para criar mais entidades)
    for (let i = 0; i < DENSITY_MULTIPLIER; i++) {
      iconPaths.forEach(path => {
        const img = new Image();
        img.src = path;
        const isRocket = path.includes("start-up.png");
        
        // Velocidade base lenta para efeito "travado" retrô
        const baseSpeed = 0.2 + Math.random() * 0.3;

        icons.push({
          img,
          isRocket,
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          // Foguete não move em X, sobe em Y. Outros movem aleatoriamente.
          dx: isRocket ? 0 : (Math.random() - 0.5) * baseSpeed,
          dy: isRocket ? -baseSpeed * 1.5 : (Math.random() - 0.5) * baseSpeed,
          size: 28 + Math.random() * 12, // Tamanho entre 28px e 40px
          opacity: 0.4 + Math.random() * 0.4,
          opacitySpeed: (Math.random() - 0.5) * 0.01
        });
      });
    }

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    window.addEventListener('resize', resize);
    resize();

    let animationFrameId: number;

    const render = () => {
      // 1. Fundo Base
      ctx.fillStyle = "#1a0033";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 2. Grade Quadriculada (Desenhada ANTES dos ícones para ficarem por baixo)
      ctx.strokeStyle = "rgba(0, 186, 255, 0.08)"; // Azul neon bem sutil
      ctx.lineWidth = 1;
      ctx.beginPath();

      const gridSize = 50; // Tamanho do quadrado da grade

      // Linhas verticais
      for (let x = 0; x <= canvas.width; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
      }

      // Linhas horizontais
      for (let y = 0; y <= canvas.height; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
      }
      ctx.stroke();

      // 3. Desenhar Ícones (POR CIMA da grade)
      icons.forEach(icon => {
        // Só desenha se a imagem carregou
        if (!icon.img.complete) return;

        // Efeito de pulsação na opacidade
        icon.opacity += icon.opacitySpeed;
        if (icon.opacity > 0.8 || icon.opacity < 0.3) icon.opacitySpeed *= -1;
        
        ctx.globalAlpha = icon.opacity;
        ctx.drawImage(icon.img, icon.x, icon.y, icon.size, icon.size);

        // Movimento
        icon.x += icon.dx;
        icon.y += icon.dy;

        // Regras de colisão e loop
        if (icon.isRocket) {
          // Regra especial: Foguete sobe e ressurge embaixo
          if (icon.y < -icon.size) {
            icon.y = canvas.height + icon.size;
            icon.x = Math.random() * (canvas.width - icon.size);
          }
        } else {
          // Regra padrão: Rebater nas paredes
          if (icon.x < 0 || icon.x > canvas.width - icon.size) icon.dx *= -1;
          if (icon.y < 0 || icon.y > canvas.height - icon.size) icon.dy *= -1;
        }
      });

      ctx.globalAlpha = 1.0;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 pointer-events-none"
      style={{ imageRendering: 'pixelated' }}
    />
  );
};