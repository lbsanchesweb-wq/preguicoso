import React from 'react';
import { Copy, Check, Terminal } from 'lucide-react';

interface CodeViewerProps {
  filename: string;
  code: string;
  language?: string;
}

export const CodeViewer: React.FC<CodeViewerProps> = ({ filename, code }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full my-4 relative group">
        {/* Retro CRT Bezel Effect */}
        <div className="absolute -inset-1 bg-gradient-to-r from-lazy-neonBlue to-lazy-neonPink rounded-lg opacity-20 blur group-hover:opacity-40 transition duration-500"></div>
        
        <div className="relative rounded-lg overflow-hidden border-2 border-lazy-panel bg-lazy-dark shadow-2xl">
            {/* Terminal Header */}
            <div className="flex items-center justify-between px-4 py-2 bg-lazy-panel border-b-2 border-lazy-base">
                <div className="flex items-center gap-2">
                    <Terminal size={14} className="text-lazy-yellow" />
                    <span className="text-xs font-bold text-lazy-yellow tracking-wider uppercase">
                        root@preguicoso:~/{filename}
                    </span>
                </div>
                <button
                onClick={handleCopy}
                className="flex items-center gap-2 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-wider border border-lazy-neonBlue/30 hover:bg-lazy-neonBlue/20 text-lazy-neonBlue transition-all"
                >
                {copied ? <Check size={12} /> : <Copy size={12} />}
                {copied ? 'COPIADO!' : 'COPY'}
                </button>
            </div>

            {/* Terminal Body */}
            <div className="p-4 overflow-x-auto bg-[#0a0a12]">
                <pre className="text-xs sm:text-sm font-mono text-lazy-text whitespace-pre leading-relaxed">
                <code className="selection:bg-lazy-neonPink selection:text-white">{code}</code>
                </pre>
            </div>
        </div>
    </div>
  );
};