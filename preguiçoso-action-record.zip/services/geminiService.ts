
import { GoogleGenAI, SchemaType } from "@google/genai";
import { AgentConfig } from "../types";

const SYSTEM_INSTRUCTION = `Você é um Agente de Automação Inteligente especializado em interpretar comandos em linguagem natural (Português do Brasil) e transformá-los em automação de navegador.

Objetivo: Analisar uma entrada (texto descritivo, JSON de gravação ou script) e converter em dois artefatos:
1. 'playbook': Um resumo estruturado das etapas em JSON, focando na intenção do usuário.
2. 'script': O código JavaScript (Playwright) executável e comentado.

Regras para Interpretação de Linguagem Natural:
1. Identifique verbos de ação: "Acessar", "Clicar", "Preencher", "Baixar", "Esperar".
2. Extraia entidades: URLs, seletores (infira se não explícito), textos de botões, credenciais.
3. Se o usuário der credenciais de exemplo, use-as no script.

Regras para o 'script' (Código Playwright):
1. Deve exportar uma função assíncrona chamada 'runAutomation(config)'.
2. Comente cada etapa em PT-BR (ex: "// Etapa 1 - Navegar para...").
3. Use seletores robustos (priorize id, name, text=, data-testid).
4. Em caso de erro, capture screenshot usando 'config.screenshotPath'.
5. O script deve retornar um objeto de relatório final.

Regras para o 'playbook' (JSON Estruturado):
1. Deve ser uma lista de objetos "etapas".
2. Cada etapa deve ter: "ação", "seletor" (opcional), "valor" (opcional), "texto" (opcional) e "descrição".

Saída Esperada (JSON):
Deve retornar um objeto JSON com as chaves "playbook" (objeto) e "script" (string contendo o código JS).
`;

export const generateAutomationArtifacts = async (config: AgentConfig): Promise<{ script: string, playbook: any }> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API_KEY não encontrada nas variáveis de ambiente.");
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = `
      URL Alvo (Referência): ${config.targetUrl}
      
      ENTRADA (Comando Natural ou Gravação):
      ${config.taskDescription}
      
      TAREFA:
      1. Analise a entrada acima. Se for texto corrido, quebre em etapas lógicas. Se for JSON, converta.
      2. Gere um arquivo 'playbook.json' seguindo este formato:
         {
           "etapas": [
             {"ação": "abrir", "url": "...", "descrição": "Abrir site"},
             {"ação": "preencher", "seletor": "input[name='email']", "valor": "...", "descrição": "Inserir email"},
             {"ação": "clicar", "seletor": "button[type='submit']", "descrição": "Fazer login"}
           ]
         }
      3. Gere um arquivo 'script.js' (string) usando Playwright.
      
      Retorne APENAS o JSON com os campos 'playbook' e 'script'.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        temperature: 0.2,
        maxOutputTokens: 8000,
      }
    });

    const responseText = response.text || "{}";
    const parsed = JSON.parse(responseText);

    return {
      script: parsed.script || "// Erro na geração do script",
      playbook: parsed.playbook || { etapas: [] }
    };

  } catch (error) {
    console.error("Erro na geração Gemini:", error);
    throw error;
  }
};