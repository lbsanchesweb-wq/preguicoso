
import { AgentConfig } from '../types';

export const generateDockerfile = (): string => {
  return `# Use a imagem oficial do Playwright
FROM mcr.microsoft.com/playwright:v1.41.0-jammy

# Definir diretório de trabalho
WORKDIR /app

# Copiar arquivos de pacote
COPY package*.json ./

# Instalar dependências
RUN npm install --production

# Copiar o restante do código da aplicação
COPY . .

# Definir variáveis de ambiente
ENV NODE_ENV=production
ENV PLAYWRIGHT_HEADLESS=true
ENV LOG_PATH=./logs
ENV SCREENSHOT_PATH=./screenshots
ENV PORT=8080

# Garantir que pastas de logs e screenshots existam
RUN mkdir -p logs screenshots

# Expor a porta para o Cloud Run
EXPOSE 8080

# Rodar a aplicação (servidor)
CMD ["node", "index.js"]
`;
};

export const generatePackageJson = (name: string): string => {
  return `{
  "name": "${name}",
  "version": "1.0.0",
  "description": "Agente Playwright com servidor HTTP para Cloud Run e Pub/Sub",
  "main": "index.js",
  "type": "module",
  "scripts": {
    "start": "node index.js",
    "test": "node index.js"
  },
  "dependencies": {
    "playwright": "^1.41.0",
    "@google-cloud/secret-manager": "^5.0.1",
    "@google-cloud/logging": "^10.0.0",
    "express": "^4.18.2"
  }
}`;
};

export const generateEntrypoint = (config: AgentConfig): string => {
  return `import express from 'express';
import { SecretManagerServiceClient } from '@google-cloud/secret-manager';
import { runAutomation } from './automation.js';
import fs from 'fs';
import path from 'path';

// Configurações de Ambiente
const PROJECT_ID = process.env.GCP_PROJECT_ID || '${config.projectId}';
const LOG_PATH = process.env.LOG_PATH || './logs';
const SCREENSHOT_PATH = process.env.SCREENSHOT_PATH || './screenshots';
const ALERT_EMAIL = process.env.ALERT_EMAIL || '${config.alertEmail}';
const ALERT_WHATSAPP = process.env.ALERT_WHATSAPP || '${config.alertWhatsapp}';

const client = new SecretManagerServiceClient();
const app = express();
app.use(express.json());

// --- Sistema de Logs Estruturados ---
const log = (severity, message, data = {}) => {
  const entry = { 
    timestamp: new Date().toISOString(), 
    severity, 
    message, 
    component: 'agente-automacao',
    ...data 
  };
  // Cloud Logging captura stdout como JSON
  console.log(JSON.stringify(entry));
};

// --- Sistema de Alertas ---
async function sendAlert(type, errorMessage) {
  log('WARNING', \`Enviando alerta via \${type}...\`, { destination: type === 'EMAIL' ? ALERT_EMAIL : ALERT_WHATSAPP });
  
  // Simulação de envio (implementar integração real com SendGrid/Twilio aqui)
  console.log(\`>>> ALERTA [\${type}]: Falha na automação! Erro: \${errorMessage}\`);
  console.log(\`>>> Destino: \${type === 'EMAIL' ? ALERT_EMAIL : ALERT_WHATSAPP}\`);
}

// --- Gerenciador de Segredos ---
async function accessSecret(secretName) {
  if (!secretName) return null;
  try {
    const name = \`projects/\${PROJECT_ID}/secrets/\${secretName}/versions/latest\`;
    const [version] = await client.accessSecretVersion({ name });
    return version.payload.data.toString();
  } catch (error) {
    log('WARNING', \`Falha ao acessar secret: \${secretName}\`, { error: error.message });
    return null;
  }
}

// --- Handler da Automação ---
async function executeJob() {
  const startTime = Date.now();
  log('INFO', 'Iniciando execução do Playbook agendado...');

  // Garantir diretórios
  [LOG_PATH, SCREENSHOT_PATH].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  });

  try {
    // 1. Injeção de Segredos
    const secretValue = await accessSecret('${config.secretName}');
    if (secretValue) process.env.AGENT_CREDENTIALS = secretValue;

    // 2. Execução do Script Playwright
    const result = await runAutomation({
      headless: process.env.PLAYWRIGHT_HEADLESS === 'true',
      screenshotPath: SCREENSHOT_PATH,
      logPath: LOG_PATH
    });

    const duration = Date.now() - startTime;
    
    // 3. Relatório de Sucesso
    log('INFO', 'Automação concluída com sucesso.', { 
      durationMs: duration,
      resultSummary: result 
    });

    return { status: 'SUCCESS', duration, result };

  } catch (error) {
    const duration = Date.now() - startTime;
    
    // 4. Tratamento de Erro e Alertas
    log('ERROR', 'Falha crítica na execução.', { 
      durationMs: duration,
      error: error.message,
      stack: error.stack
    });

    // Disparar alertas assincronamente
    await Promise.all([
      sendAlert('EMAIL', error.message),
      sendAlert('WHATSAPP', error.message)
    ]);

    throw error;
  }
}

// --- Servidor HTTP para Pub/Sub ---
app.post('/', async (req, res) => {
  try {
    // O Pub/Sub envia a mensagem no corpo em formato { message: { data: 'base64...' } }
    // Podemos decodificar se houver parâmetros dinâmicos, mas aqui vamos apenas disparar.
    
    const result = await executeJob();
    res.status(200).json(result);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  log('INFO', \`Servidor do Agente ouvindo na porta \${PORT}\`);
});
`;
};

export const generateCloudBuild = (config: AgentConfig): string => {
  return `steps:
  # 1. Construir imagem
  - name: 'gcr.io/cloud-builders/docker'
    args: ['build', '-t', 'gcr.io/${config.projectId}/${config.serviceName}', '.']

  # 2. Push para Container Registry
  - name: 'gcr.io/cloud-builders/docker'
    args: ['push', 'gcr.io/${config.projectId}/${config.serviceName}']

  # 3. Deploy no Cloud Run
  - name: 'gcr.io/google.com/cloudsdktool/cloud-sdk'
    entrypoint: gcloud
    args:
      - 'run'
      - 'deploy'
      - '${config.serviceName}'
      - '--image'
      - 'gcr.io/${config.projectId}/${config.serviceName}'
      - '--region'
      - '${config.region}'
      - '--platform'
      - 'managed'
      - '--no-allow-unauthenticated' # Requer autenticação (seguro para Pub/Sub)
      - '--set-env-vars'
      - 'PLAYWRIGHT_HEADLESS=true'
      - '--set-env-vars'
      - 'GCP_PROJECT_ID=${config.projectId}'
      - '--set-env-vars'
      - 'ALERT_EMAIL=${config.alertEmail}'

images:
  - 'gcr.io/${config.projectId}/${config.serviceName}'
`;
};

export const generateSetupScript = (config: AgentConfig): string => {
  return `#!/bin/bash
# Script de Infraestrutura: Scheduler -> Pub/Sub -> Cloud Run
# Uso: chmod +x setup.sh && ./setup.sh

# Variáveis
PROJECT_ID="${config.projectId}"
REGION="${config.region}"
SERVICE_NAME="${config.serviceName}"
TOPIC_NAME="disparar-automacao-${config.serviceName}"
SUBSCRIPTION_NAME="sub-automacao-${config.serviceName}"
SCHEDULER_JOB_NAME="job-${config.serviceName}"
SERVICE_ACCOUNT="agente-automacao"

echo "🚀 Iniciando Configuração de Infraestrutura de Agendamento..."

# 1. Criar Tópico Pub/Sub
echo "📡 Criando Tópico Pub/Sub: $TOPIC_NAME"
if ! gcloud pubsub topics describe $TOPIC_NAME --project $PROJECT_ID &>/dev/null; then
    gcloud pubsub topics create $TOPIC_NAME --project $PROJECT_ID
else
    echo "Tópico já existe."
fi

# 2. Criar Conta de Serviço para o Invoker (Scheduler -> Pub/Sub)
echo "👤 Verificando Conta de Serviço..."
if ! gcloud iam service-accounts describe $SERVICE_ACCOUNT@$PROJECT_ID.iam.gserviceaccount.com --project $PROJECT_ID &>/dev/null; then
    gcloud iam service-accounts create $SERVICE_ACCOUNT --display-name="Executor de Automação" --project $PROJECT_ID
fi

# 3. Configurar Cloud Scheduler
echo "⏰ Configurando Cloud Scheduler ($SCHEDULER_JOB_NAME) para: ${config.cronSchedule}"
if gcloud scheduler jobs describe $SCHEDULER_JOB_NAME --location $REGION --project $PROJECT_ID &>/dev/null; then
    gcloud scheduler jobs delete $SCHEDULER_JOB_NAME --location $REGION --project $PROJECT_ID --quiet
fi

gcloud scheduler jobs create pubsub $SCHEDULER_JOB_NAME \\
  --schedule="${config.cronSchedule}" \\
  --topic=$TOPIC_NAME \\
  --message-body='{"acao":"executar_playbook"}' \\
  --location=$REGION \\
  --project=$PROJECT_ID \\
  --description="Disparo automático do agente via Pub/Sub"

# 4. (PÓS-DEPLOY) Conectar Pub/Sub ao Cloud Run
# Nota: O Cloud Run precisa estar implantado para pegarmos a URL.
# Abaixo está o comando para criar a assinatura Push segura.

echo "
⚠️  IMPORTANTE: PÓS-DEPLOY
Após o deploy do Cloud Run, execute o comando abaixo para conectar o tópico ao serviço:

SERVICE_URL=\$(gcloud run services describe $SERVICE_NAME --platform managed --region $REGION --format 'value(status.url)' --project $PROJECT_ID)

# Criar conta de serviço com permissão de invocar
gcloud run services add-iam-policy-binding $SERVICE_NAME \\
  --member=serviceAccount:service-$PROJECT_NUMBER@gcp-sa-pubsub.iam.gserviceaccount.com \\
  --role=roles/run.invoker \\
  --region=$REGION --project=$PROJECT_ID

# Criar assinatura push
gcloud pubsub subscriptions create $SUBSCRIPTION_NAME \\
  --topic=$TOPIC_NAME \\
  --push-endpoint=\$SERVICE_URL \\
  --push-auth-service-account=$SERVICE_ACCOUNT@$PROJECT_ID.iam.gserviceaccount.com \\
  --project=$PROJECT_ID
"
`;
};

export const generateLocalRunScript = (config: AgentConfig): string => {
  return `#!/bin/bash
# Executor Local (Modo Servidor)
# Uso: ./run_local.sh

echo "📦 Instalando dependências..."
npm install
npx playwright install chromium

echo "🔧 Configurando variáveis de ambiente..."
export GCP_PROJECT_ID="${config.projectId}"
export PLAYWRIGHT_HEADLESS=false
export PORT=8080
export ALERT_EMAIL="${config.alertEmail}"

echo "▶️  Iniciando Servidor do Agente..."
echo "   Para testar o disparo, use outro terminal: curl -X POST http://localhost:8080/"
node index.js
`;
};
